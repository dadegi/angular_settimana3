import { Component, OnInit } from "@angular/core";
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  ValidationErrors,
  Validators,
} from "@angular/forms";
@Component({
  selector: 'app-f1',
  template: `
     <div class="container mt-3">
      <h1>Reactive Form</h1>
      <div class="container">
        <div class="row">
          <div class="col">
            <form [formGroup]="form" (ngSubmit)="onSubmit()">
              <div formGroupName="userInfo">
                <div class="form-group">
                  <label for="username">Username</label>
                  <input
                    type="text"
                    formControlName="username"
                    id="username"
                    class="form-control"
                  />
                  <span
                    *ngIf="
                      getFormC('userInfo.username')?.invalid &&
                      getFormC('userInfo.username')?.touched
                    "
                  >
                    <ng-container
                      *ngIf="getErrorC('userInfo.username', 'required')"
                      >Campo Username non valido</ng-container
                    >
                    <ng-container
                      *ngIf="getErrorC('userInfo.username', 'usernameProibito')"
                      >Nome proibito</ng-container
                    >
                  </span>
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input
                    formControlName="email"
                    type="email"
                    id="email"
                    class="form-control"
                  />
                  <span *ngIf="getFormC('userInfo.email')?.pending"
                    >Sto controllando..
                  </span>
                  <span *ngIf="getErrorC('userInfo.email', 'emailProibita')"
                    >email proibita</span
                  >
                </div>
              </div>

              <div class="radio" *ngFor="let genere of generi">
                <label>
                  <input
                    formControlName="genere"
                    type="radio"
                    [value]="genere"
                  />
                  {{ genere }}
                </label>
              </div>
              <div formArrayName="sports" class="mb-3">
                <h3>I miei Sport</h3>
                <button class="btn btn-success" (click)="addSport()">
                  Aggiungi Sport
                </button>
                <div
                  class="form-group mb-3"
                  *ngFor="let sportC of getSportsF(); let i = index"
                >
                  <input
                    class="form-control"
                    type="text"
                    [formControlName]="i"
                  />
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Invia</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [
  ]
})
export class F1Component implements OnInit {

  generi = ["uomo", "donna"];
  form!: FormGroup;

  usernameProibiti = ["luca", "Marco"];
  constructor(private fb: FormBuilder) {}
  usernameProibitiValidatore = (formC: FormControl) => {
    if (this.usernameProibiti.includes(formC.value)) {
      return { usernameProibito: true };
    }
    return null;
  };

  ngOnInit(): void {
    this.form = this.fb.group({
      userInfo: this.fb.group({
        username: this.fb.control(null, [
          Validators.required,
          this.usernameProibitiValidatore,
        ]),
        email: this.fb.control(
          null,
          [Validators.required, Validators.email],
          this.emailProibita
        ),
      }),
      genere: this.fb.control("donna"),
      sports: this.fb.array([]),
    });
    this.form.statusChanges.subscribe((value) => {
      console.log(value);
    });
    this.form.valueChanges.subscribe((value) => {
      console.log(value);
    });
  }

  // usernameProibitiValidatore(formC:FormControl){
  //   if (this.usernameProibiti.includes(formC.value)) {
  //     return {'usernameProibito':true}
  //   }
  //   return null
  // }

  getErrorC(name: string, error: string) {
    return this.form.get(name)?.errors![error];
  }
  getFormC(name: string) {
    return this.form.get(name);
  }
  getSportsF() {
    return (this.form.get("sports") as FormArray).controls;
  }
  addSport() {
    const control = new FormControl(null, Validators.required);
    (this.form.get("sports") as FormArray).push(control);
  }

  emailProibita(formC: AbstractControl) {
    return new Promise<ValidationErrors | null>((resolve, reject) => {
      setTimeout(() => {
        if (formC.value == "prova@dd.com") {
          resolve({ emailProibita: true });
        } else {
          resolve(null);
        }
      }, 2000);
    });
  }
  onSubmit() {
    console.log(this.form);
    this.form.reset()
  }
}
