import { Component, OnInit } from "@angular/core";
import { TodoService } from "./todo.service";


@Component({
  selector: "app-root",
  template: `
  <nav class="navbar navbar-expand navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" >Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
      <div class="navbar-nav">
        <!-- <a class="nav-link active" aria-current="page" [routerLink]="['/']" routerLinkActive="active" >Home</a> -->
        <a class="nav-link" [routerLink]="['/f1']" routerLinkActive="active"  >Features1</a>
        <a class="nav-link" [routerLink]="['/f2']" routerLinkActive="active" >Features2</a>
      </div>
    </div>
  </div>
</nav>
<router-outlet></router-outlet>
  `,
  styles: [],
})
export class AppComponent{
  constructor(private todoSrv:TodoService){}
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    // this.todoSrv.get().toPromise()
  }
 
}
