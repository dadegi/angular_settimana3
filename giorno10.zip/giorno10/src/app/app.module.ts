import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RouterModule, Route } from "@angular/router";
import { HttpClientModule } from "@angular/common/http";
import { AppComponent } from "./app.component";
const routes: Route[] = [
  {
    path: "f1",
    loadChildren: () => import("./f1/f1.module").then((m) => m.F1Module),
  },
  {
    path: "f2",
    loadChildren: () => import("./f2/f2.module").then((m) => m.F2Module),
  },
  {
    path: "",
    pathMatch:"full",
    redirectTo:"f1"
  },
];

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, RouterModule.forRoot(routes),HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
