import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-f2',
  template: `
    <p>
      f2 funziona con netifly
    </p>
  `,
  styles: [
  ]
})
export class F2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
