import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { F2Component } from './f2.component';


const routes: Routes = [
  { path: '', component: F2Component }
];

@NgModule({
  declarations: [
    F2Component
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class F2Module { }
