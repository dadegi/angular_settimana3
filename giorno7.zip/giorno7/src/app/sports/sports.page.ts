import { Component, OnInit } from "@angular/core";
import { LogService } from "../log.service";

@Component({
  template: `
    <div class="container">
    <app-lista-item>
      <app-item
        class="mb-3"
        *ngFor="let sport of sports"
        [titolo]="sport.nome"
      ></app-item>
    </app-lista-item> 
     </div>
  `,
  styles: [],
})
export class SportsPage implements OnInit {
  sports: any = [
    {
      nome: "calcio",
    },
    {
      nome: "tennis",
    },
  ];
  constructor(private logSrv:LogService) {}

  ngOnInit(): void {

    this.logSrv.printLog('chiamo da sports page')

  }
}
