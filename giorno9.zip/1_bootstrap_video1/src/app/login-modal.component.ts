import { Component, Input, OnInit } from "@angular/core";

@Component({
  selector: "app-login-modal",
  template: `
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">{{title}}</h5>
      <button
        type="button"
        class="btn-close"
        data-bs-dismiss="modal"
        aria-label="Close"
      ></button>
    </div>
    <div class="modal-body">...</div>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
        Close
      </button>
      <button type="button" class="btn btn-primary">Save changes</button>
    </div>
  `,
  styles: [],
})
export class LoginModalComponent implements OnInit {
  @Input()title!:string
  constructor() {}

  ngOnInit(): void {}
}
