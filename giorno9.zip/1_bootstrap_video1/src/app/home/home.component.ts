import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
      <p><ngb-progressbar type="success" [value]="25"></ngb-progressbar></p>

  `,
  styles: [
  ]
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
