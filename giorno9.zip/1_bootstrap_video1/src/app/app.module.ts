import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { AppComponent } from "./app.component";
import { NavComponent } from "./nav.component";
import { LoginModalComponent } from "./login-modal.component";
import { NgbCollapseModule, NgbModalModule, NgbProgressbarModule } from "@ng-bootstrap/ng-bootstrap";
import { RouterModule } from "@angular/router";

@NgModule({
  declarations: [AppComponent, NavComponent, LoginModalComponent],
  imports: [
    BrowserModule,
    NgbCollapseModule,
    NgbModalModule,
    NgbProgressbarModule,
    RouterModule.forRoot([
      {
        path: "profilo",
        loadChildren: () =>
          import("./profilo/profilo.module").then((m) => m.ProfiloModule),
      },
      { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
