import { Component } from "@angular/core";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { LoginModalComponent } from "./login-modal.component";

@Component({
  selector: "app-root",
  template: `
    <app-nav></app-nav>
    <button type="button" (click)="openLogin()" class="btn btn-primary" >
      apri login
    </button>

<router-outlet>
<!-- Button trigger modal -->
  `,
  styles: [],
})
export class AppComponent {
  constructor(private bModal:NgbModal){}

  openLogin(){
    const modalr = this.bModal.open(LoginModalComponent)
    modalr.componentInstance.title = 'Login utente'
  }

}
