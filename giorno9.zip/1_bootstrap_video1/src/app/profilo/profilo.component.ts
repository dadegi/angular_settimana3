import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilo',
  template: `
    <p><ngb-progressbar type="success" [value]="25"></ngb-progressbar></p>

  `,
  styles: [
  ]
})
export class ProfiloComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
