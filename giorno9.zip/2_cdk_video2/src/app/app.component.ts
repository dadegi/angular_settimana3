import {
  CdkDragDrop,
  moveItemInArray,
  transferArrayItem,
} from "@angular/cdk/drag-drop";
import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  template: `
    <style>
      .cont {
        height: 300px;
        width: 100%;
        overflow: auto;
      }
      .colc {
        width: 200px;
        border: 1px solid black;
      }
    </style>
    <div style="text-align:center" class="content">
      <h1 class="mb-5">Hola</h1>
      <!-- infinite scroll -->
      <!-- <cdk-virtual-scroll-viewport itemSize="50" class="list-group cont">
        <div class="list-group-item" *cdkVirtualFor="let item of items">{{ item }}</div>
      </cdk-virtual-scroll-viewport> -->

      <!-- drag and drop -->
      <div cdkDropListGroup class="d-flex justify-content-between">
        <div
          cdkDropList
          itemSize="50"
          (cdkDropListDropped)="drop($event)"
          class="list-group colc"
          [cdkDropListData]="items"
        >
          <div cdkDrag class="list-group-item" *ngFor="let item of items">
            {{ item }}
          </div>
        </div>
        <div
          cdkDropList
          itemSize="50"
          (cdkDropListDropped)="drop($event)"
          class="list-group colc"
          [cdkDropListData]="items2"
        >
          <div cdkDrag class="list-group-item" *ngFor="let item of items2">
            {{ item }}
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class AppComponent {
  items = Array(6)
    .fill(1)
    .map((_, i) => `elemento ${i}`);

  items2 = [];

  drop($event: CdkDragDrop<any>) {
    console.log($event);
    if ($event.previousContainer === $event.container) {
      moveItemInArray($event.container.data, $event.previousIndex, $event.currentIndex);
      return;
    }
    transferArrayItem(
      $event.previousContainer.data,
      $event.container.data,
      $event.previousIndex,
      $event.currentIndex
    );
  }
}
