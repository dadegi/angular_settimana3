import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  template: `
    <style>
      .content {
        padding: 16px;
      }
      .content mat-card {
      }
    </style>
    <mat-toolbar color="primary"> Colori </mat-toolbar>
    <div class="content">
      <div fxLayout="row wrap" fxLayoutGap="16px grid" >
        <div fxFlex="25%" [fxFlex.xs]="smallD" fxFlex.sm="33%" *ngFor="let card of [1, 2, 3, 4,5,6,7,8,9,10]">
          <mat-card >
            <mat-card-header>
              <mat-card-title>Colore n{{card}}</mat-card-title>
            </mat-card-header>
            <img mat-card-image src="assets/celeste.jpeg" />
            <mat-card-content>
              <p>il colore del mare</p>
            </mat-card-content>
            <mat-card-actions>
              <button mat-button>mi piace</button>
              <button mat-button>condividi</button>
            </mat-card-actions>
          </mat-card>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class AppComponent {
  smallD = "100%"
}
