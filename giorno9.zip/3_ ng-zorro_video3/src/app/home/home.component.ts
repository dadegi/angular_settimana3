import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
   <nz-card nzTitle="ciao" ></nz-card>
   <nz-alert nzMessage="provca" nzType="error"></nz-alert>
  `,
  styles: [
  ]
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
