import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info',
  template: `
   <nz-alert nzMessage="sono molto pericolosoo" ></nz-alert>
  `,
  styles: [
  ]
})
export class InfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
