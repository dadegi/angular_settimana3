import { Component } from "@angular/core";

@Component({
  selector: "app-root",
  template: `
  <style>
    .dash-layout{
      height: 100vh;
    }
    .menu{
      background-color: white;
    }
    ul{
      height: 100%;
    }
    nz-content{
      margin: 20px;
    }
    .content-w{
      padding: 24px;
      background-color: white;
      height: 100%;
    }
  </style>
   <nz-layout class="dash-layout">
     <nz-sider class="menu">
       <ul nz-menu nzTheme="dark" >
         <li nz-menu-item ><a routerLink="home"   >Home</a></li>
         <li nz-menu-item ><a routerLink="profile"   >Profilo</a></li>
         <li nz-menu-item ><a routerLink="info"   >info</a></li>
       </ul>
     </nz-sider>
     <nz-layout>
       <nz-content>
         <div class="content-w">
           <router-outlet></router-outlet>

         </div>
       </nz-content>
     </nz-layout>

   </nz-layout>
  `,
  styles: [],
})
export class AppComponent {
}
